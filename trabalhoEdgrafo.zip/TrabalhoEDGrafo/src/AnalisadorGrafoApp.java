import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Representação interna e algoritmos de análise.
 */
class Grafo {
    private Map<Integer, List<Integer>> listaAdjacencia;

    public Grafo() {
        this.listaAdjacencia = new HashMap<>();
    }

    public void adicionarVertice(int vertice) {
        listaAdjacencia.putIfAbsent(vertice, new ArrayList<>());
    }

    public void adicionarAresta(int origem, int destino) {
        adicionarVertice(origem);
        adicionarVertice(destino);
        // Evitar linhas duplas
        if (!listaAdjacencia.get(origem).contains(destino)) {
            listaAdjacencia.get(origem).add(destino);
        }
        if (!listaAdjacencia.get(destino).contains(origem)) {
            listaAdjacencia.get(destino).add(origem);
        }
    }

    public void limpar() {
        listaAdjacencia.clear();
    }

    // Método para obter a lista para o desenho
    public Map<Integer, List<Integer>> obterListaAdjacencia() {
        return listaAdjacencia;
    }

    public boolean estaVazio() {
        return listaAdjacencia.isEmpty();
    }

    // --- Algoritmos ---

    public int contarComponentesConexos() {
        Set<Integer> visitados = new HashSet<>();
        int numeroComponentes = 0;
        
        // Iteração sobre as chaves, ou seja, vértices
        for (Integer vertice : listaAdjacencia.keySet()) {
            if (!visitados.contains(vertice)) {
                numeroComponentes++;
                buscaEmProfundidadeConectividade(vertice, visitados);
            }
        }
        return numeroComponentes;
    }

    private void buscaEmProfundidadeConectividade(int verticeAtual, Set<Integer> visitados) {
        visitados.add(verticeAtual);
        for (Integer vizinho : listaAdjacencia.get(verticeAtual)) {
            if (!visitados.contains(vizinho)) {
                buscaEmProfundidadeConectividade(vizinho, visitados);
            }
        }
    }

    public boolean possuiCiclo() {
        Set<Integer> visitados = new HashSet<>();
        for (Integer vertice : listaAdjacencia.keySet()) {
            if (!visitados.contains(vertice)) {
                // -1 significa que não há pai para o nó inicial
                if (buscaEmProfundidadeCiclo(vertice, visitados, -1)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean buscaEmProfundidadeCiclo(int verticeAtual, Set<Integer> visitados, int pai) {
        visitados.add(verticeAtual);
        
        for (Integer vizinho : listaAdjacencia.get(verticeAtual)) {
            if (!visitados.contains(vizinho)) {
                if (buscaEmProfundidadeCiclo(vizinho, visitados, verticeAtual)) {
                    return true;
                }
            } else if (vizinho != pai) {
                // Se o vizinho já foi visitado e não é o pai de onde imediatamente viemos, achamos um ciclo
                return true;
            }
        }
        return false;
    }
}

/**
 * Painel personalizado para desenhar o grafo.
 */
class PainelGrafo extends JPanel {
	private static final long serialVersionUID = 1L;
    private Grafo grafo;

    public PainelGrafo(Grafo grafo) {
        this.grafo = grafo;
        this.setBackground(Color.WHITE);
        this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
    }

   
    @Override
    protected void paintComponent(Graphics graficos) {
        super.paintComponent(graficos);
        
       
        Graphics2D graficos2d = (Graphics2D) graficos;
        graficos2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Map<Integer, List<Integer>> adjacencia = grafo.obterListaAdjacencia();
        
        if (adjacencia.isEmpty()) {
            graficos2d.drawString("O grafo será desenhado aqui após a análise.", 20, 30);
            return;
        }

        // Configurações do Layout
        int larguraPainel = getWidth();
        int alturaPainel = getHeight();
        int centroX = larguraPainel / 2;
        int centroY = alturaPainel / 2;
        int raio = Math.min(larguraPainel, alturaPainel) / 2 - 40;
        int tamanhoVertice = 30; // Diâmetro do círculo do vértice

        // Mapear vértices para coordenadas (X, Y)
        Map<Integer, Point> mapaCoordenadas = new HashMap<>();
        List<Integer> listaVertices = new ArrayList<>(adjacencia.keySet());
        Collections.sort(listaVertices); // Ordenar para ficar visualmente organizado

        int totalVertices = listaVertices.size();
        double passoAngular = 2 * Math.PI / totalVertices;

        // Calcular posições
        for (int i = 0; i < totalVertices; i++) {
            int vertice = listaVertices.get(i);
            // Matemática para distribuir em círculo (Trigonometria)
            int x = centroX + (int) (raio * Math.cos(i * passoAngular));
            int y = centroY + (int) (raio * Math.sin(i * passoAngular));
            mapaCoordenadas.put(vertice, new Point(x, y));
        }

        // 1. Desenhar Arestas (Linhas)
        graficos2d.setColor(Color.GRAY);
        graficos2d.setStroke(new BasicStroke(2)); // Espessura da linha

        for (Integer origem : adjacencia.keySet()) {
            Point pontoOrigem = mapaCoordenadas.get(origem);
            for (Integer destino : adjacencia.get(origem)) {
                Point pontoDestino = mapaCoordenadas.get(destino);
                
                if (pontoOrigem != null && pontoDestino != null) {
                    graficos2d.drawLine(pontoOrigem.x, pontoOrigem.y, pontoDestino.x, pontoDestino.y);
                }
            }
        }

        //  Desenhar Vértices (Círculos) e Texto
        for (Integer vertice : listaVertices) {
            Point ponto = mapaCoordenadas.get(vertice);
            int posX = ponto.x - (tamanhoVertice / 2); // Centralizar o círculo no ponto
            int posY = ponto.y - (tamanhoVertice / 2);

            // Preenchimento do nó (Azul)
            graficos2d.setColor(new Color(100, 149, 237)); 
            graficos2d.fillOval(posX, posY, tamanhoVertice, tamanhoVertice);

            // Borda do nó (Cinza Escuro)
            graficos2d.setColor(Color.DARK_GRAY);
            graficos2d.drawOval(posX, posY, tamanhoVertice, tamanhoVertice);

            // Número do vértice (Texto)
            graficos2d.setColor(Color.WHITE);
            graficos2d.setFont(new Font("Arial", Font.BOLD, 14));
            
            // Centralizar texto dentro do círculo
            FontMetrics metricasFonte = graficos2d.getFontMetrics();
            String textoNumero = String.valueOf(vertice);
            int larguraTexto = metricasFonte.stringWidth(textoNumero);
            int alturaTexto = metricasFonte.getAscent();
            
            graficos2d.drawString(textoNumero, ponto.x - (larguraTexto / 2), ponto.y + (alturaTexto / 2) - 2);
        }
    }
}

/**
 * Interface Gráfica Principal.
 */
public class AnalisadorGrafoApp extends JFrame {
	private static final long serialVersionUID = 1L;

    private Grafo grafo;
    private JTextArea areaEntradaTexto;
    private PainelGrafo painelDesenho;
    private JLabel rotuloComponentes;
    private JLabel rotuloCiclo;
    private JLabel rotuloClassificacao;

    public AnalisadorGrafoApp() {
        grafo = new Grafo();
        configurarJanela();
        inicializarComponentes();
    }

    private void configurarJanela() {
        setTitle("Analisador e Visualizador de Grafos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
    }

    private void inicializarComponentes() {
        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));
        painelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(painelPrincipal);

        //  Topo: Título
        JLabel rotuloTitulo = new JLabel("Analisador de Propriedades Estruturais");
        rotuloTitulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        rotuloTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        painelPrincipal.add(rotuloTitulo, BorderLayout.NORTH);

        // Centro: Divisor (Entrada na Esquerda, Desenho na Direita)
        
        // 1. Painel da Esquerda (Entrada e Botão)
        JPanel painelEsquerda = new JPanel(new BorderLayout(5, 5));
        
        String textoInstrucao = "<html><b>Instruções:</b><br>Digite arestas (ex: 1-2).<br>Uma por linha.</html>";
        JLabel rotuloInstrucoes = new JLabel(textoInstrucao);
        
        areaEntradaTexto = new JTextArea(15, 15); 
        areaEntradaTexto.setText("1-2\n2-3\n3-4\n4-1\n4-5"); // Exemplo padrão
        JScrollPane barraRolagemEntrada = new JScrollPane(areaEntradaTexto);
        barraRolagemEntrada.setBorder(new TitledBorder("Lista de Arestas"));
        
        JButton botaoAnalisar = new JButton("Analisar e Desenhar");
        botaoAnalisar.setFont(new Font("SansSerif", Font.BOLD, 14));
        botaoAnalisar.setBackground(new Color(70, 130, 180));
        botaoAnalisar.setForeground(Color.WHITE);
        botaoAnalisar.setFocusPainted(false);
        
        // clique do botão
        botaoAnalisar.addActionListener(evento -> processarGrafo());

        painelEsquerda.add(rotuloInstrucoes, BorderLayout.NORTH);
        painelEsquerda.add(barraRolagemEntrada, BorderLayout.CENTER);
        painelEsquerda.add(botaoAnalisar, BorderLayout.SOUTH);

        // Painel da Direita (Desenho)
        painelDesenho = new PainelGrafo(grafo);
        painelDesenho.setBorder(new TitledBorder("Visualização do Grafo"));

        // JSplitPane para dividir a tela
        JSplitPane painelDivisor = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, painelEsquerda, painelDesenho);
        painelDivisor.setDividerLocation(250); 
        painelPrincipal.add(painelDivisor, BorderLayout.CENTER);

        // Resultados 
        JPanel painelResultados = new JPanel(new GridLayout(3, 1, 5, 5));
        painelResultados.setBorder(new TitledBorder("Resultados da Análise"));
        
        rotuloComponentes = new JLabel("1. Número de Componentes Conexos: -");
        rotuloCiclo = new JLabel("2. Verificação de Ciclo: -");
        rotuloClassificacao = new JLabel("3. Classificação: -");
        
        estilizarRotulo(rotuloComponentes);
        estilizarRotulo(rotuloCiclo);
        estilizarRotulo(rotuloClassificacao);

        painelResultados.add(rotuloComponentes);
        painelResultados.add(rotuloCiclo);
        painelResultados.add(rotuloClassificacao);

        painelPrincipal.add(painelResultados, BorderLayout.SOUTH);
    }

    private void estilizarRotulo(JLabel rotulo) {
        rotulo.setFont(new Font("Monospaced", Font.BOLD, 14));
        rotulo.setForeground(new Color(30, 30, 30));
    }

    private void processarGrafo() {
        grafo.limpar();
        String textoEntrada = areaEntradaTexto.getText();
        
        if (textoEntrada.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Insira as arestas.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] linhas = textoEntrada.split("\n");
        try {
            for (String linha : linhas) {
                linha = linha.trim();
                if (linha.isEmpty()) continue;
                // Divide por hífen, espaço ou vírgula
                String[] partes = linha.split("[- ,]+");
                if (partes.length >= 2) {
                    int origem = Integer.parseInt(partes[0]);
                    int destino = Integer.parseInt(partes[1]);
                    grafo.adicionarAresta(origem, destino);
                }
            }

            if (grafo.estaVazio()) {
                JOptionPane.showMessageDialog(this, "Nenhuma aresta válida.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Executa a lógica
            executarAnalise();
            
            // Força o redesenho do painel gráfico
            painelDesenho.repaint();

        } catch (NumberFormatException excecao) {
            JOptionPane.showMessageDialog(this, "Erro: Use apenas números inteiros.\nEx: 1-2", "Erro de Formatação", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void executarAnalise() {
        int numComponentes = grafo.contarComponentesConexos();
        boolean temCiclo = grafo.possuiCiclo();

        String conectividadeTexto = (numComponentes == 1) ? "Conexo" : "Desconexo";
        String ciclicidadeTexto = temCiclo ? "Cíclico" : "Acíclico";
        String sufixoExtra = "";
        
        if (numComponentes == 1 && !temCiclo) sufixoExtra = " (Árvore)";
        else if (numComponentes > 1 && !temCiclo) sufixoExtra = " (Floresta)";

        rotuloComponentes.setText("1. Componentes Conexos: " + numComponentes);
        rotuloCiclo.setText("2. Possui Ciclo: " + (temCiclo ? "SIM" : "NÃO"));
        
        // Cores para o resultado final (HTML básico para formatar cor)
        String cor = temCiclo ? "red" : "green";
        rotuloClassificacao.setText("<html>3. Classificação: <span style='color:"+cor+"'>" + 
                conectividadeTexto + " e " + ciclicidadeTexto + sufixoExtra + "</span></html>");
    }

    // Método principal padrão do Java
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AnalisadorGrafoApp aplicativo = new AnalisadorGrafoApp();
            aplicativo.setVisible(true);
        });
    }
}